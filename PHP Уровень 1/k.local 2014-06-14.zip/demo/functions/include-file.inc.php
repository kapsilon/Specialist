<?php
$a = 1;

function foo() {
	echo "function foo()";
}
?>
