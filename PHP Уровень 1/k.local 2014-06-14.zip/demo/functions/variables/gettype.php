<HTML>
<HEAD>
<TITLE>gettype</TITLE>
</HEAD>
<BODY>
<?
	//integer
	printf("%s <BR>\n", gettype(11));
	
	//double
	printf("%s <BR>\n", gettype(7.3));

	//string
	printf("%s <BR>\n", gettype("hello"));
?>
</BODY>
</HTML>