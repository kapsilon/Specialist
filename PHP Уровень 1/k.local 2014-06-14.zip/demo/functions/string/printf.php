<HTML>
<HEAD>
<TITLE>printf</TITLE>
</HEAD>
<BODY>
<?
	printf("%-10s %5d %05.5f <BR>\n", "a string", 10, 3.14);
?>
</BODY>
</HTML>