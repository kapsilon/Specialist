<HTML>
<HEAD>
<TITLE>chop</TITLE>
</HEAD>
<BODY>
<?
	print("\"" . 
		chop("This has whitespace       ") .
		"\"");
?>
</BODY>
</HTML>