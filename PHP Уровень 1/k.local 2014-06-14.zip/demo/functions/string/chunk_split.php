<HTML>
<HEAD>
<TITLE>chunk_split</TITLE>
</HEAD>
<BODY>
<?
	$encodedData = chunk_split(base64_encode($rawData));
?>
</BODY>
</HTML>