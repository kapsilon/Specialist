<HTML>
<HEAD>
<TITLE>htmlentities</TITLE>
</HEAD>
<BODY>
<?
	$text = "Use <HTML> to begin a document.";
	print(htmlentities($text));
?>
</BODY>
</HTML>