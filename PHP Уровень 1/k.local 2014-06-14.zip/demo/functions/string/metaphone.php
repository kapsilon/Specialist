<HTML>
<HEAD>
<TITLE>metaphone</TITLE>
</HEAD>
<BODY>
<?
	print("Atkinson encodes as " . metaphone("Atkinson"));
?>
</BODY>
</HTML>