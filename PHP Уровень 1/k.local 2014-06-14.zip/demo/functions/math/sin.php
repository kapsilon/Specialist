<HTML>
<HEAD>
<TITLE>sin</TITLE>
</HEAD>
<BODY>
<?
	//prints 1
	print(sin(0.5 * M_PI));
?>
</BODY>
</HTML>