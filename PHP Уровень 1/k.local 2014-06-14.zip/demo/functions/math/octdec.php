<HTML>
<HEAD>
<TITLE>octdec</TITLE>
</HEAD>
<BODY>
<?
	//prints 497
	print(octdec("761"));
?>
</BODY>
</HTML>