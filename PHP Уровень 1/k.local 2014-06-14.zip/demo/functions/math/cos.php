<HTML>
<HEAD>
<TITLE>cos</TITLE>
</HEAD>
<BODY>
<?
	//prints 1
	print(cos(2 * pi()));
?>

</BODY>
</HTML>