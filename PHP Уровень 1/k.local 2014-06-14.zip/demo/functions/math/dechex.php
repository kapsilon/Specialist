<HTML>
<HEAD>
<TITLE>dechex</TITLE>
</HEAD>
<BODY>
<?
	//prints ff
	print(dechex(255));
?>

</BODY>
</HTML>