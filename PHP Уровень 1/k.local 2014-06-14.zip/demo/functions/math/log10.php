<HTML>
<HEAD>
<TITLE>log10</TITLE>
</HEAD>
<BODY>
<?
	//prints 3.2494429614426
	print(log10(1776));
?>
</BODY>
</HTML>