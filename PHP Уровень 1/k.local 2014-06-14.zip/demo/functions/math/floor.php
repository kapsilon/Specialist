<HTML>
<HEAD>
<TITLE>floor</TITLE>
</HEAD>
<BODY>
<?
	//prints 13
	print(floor(13.2));
?>
</BODY>
</HTML>