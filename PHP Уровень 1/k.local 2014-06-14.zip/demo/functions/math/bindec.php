<HTML>
<HEAD>
<TITLE>bindec</TITLE>
</HEAD>
<BODY>
<?
	// print largest integer 
	print("Largest Integer: ");
	print(bindec("1111111111111111111111111111111"));

	print("<BR>\n");

	// print smallest integer 
	print("Smallest Integer: ");
	print(bindec("10000000000000000000000000000000"));
	print("<BR>\n");
?>
</BODY>
</HTML>