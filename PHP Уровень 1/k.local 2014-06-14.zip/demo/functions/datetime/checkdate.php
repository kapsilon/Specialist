<HTML>
<HEAD>
<TITLE>checkdate</TITLE>
</HEAD>
<BODY>
<?
	if(checkdate(2,18,1970))
	{
		print("It is a good day");
	}
?>
</BODY>
</HTML>