<?php
  echo "<h1>Hello, cURL!</h1>";
