<?php
phpinfo();

/*
http://aurore.net/projects/php-json/

	php-json

	php-json is an extremely fast PHP C extension for JSON 
	(JavaScript Object Notation) serialisation. 
	It conforms to the JSON specification.

	It is now part of PHP 5.2.0.
*/
?>