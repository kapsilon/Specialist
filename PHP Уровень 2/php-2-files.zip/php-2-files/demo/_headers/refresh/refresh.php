<?
header("Refresh: 1");
?>
<!DOCTYPE HTML>

<html>
<head>
	<meta charset="utf-8" />
	<title>Перезапрос страницы</title>
</head>

<body>
<h1>Перезапрос страницы</h1>
<h1><?=date("H:i:s")?></h1>

</body>
</html>
