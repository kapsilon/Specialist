<?php
setcookie("userName", 'John');
?>