<HTML>
<HEAD>
<TITLE>file</TITLE>
</HEAD>
<BODY>
<?
	$myFile = file("data.txt");
	
	print_r($myFile);
?>
</BODY>
</HTML>